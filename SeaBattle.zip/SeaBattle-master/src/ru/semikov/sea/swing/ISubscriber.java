package ru.semikov.sea.swing;

public interface ISubscriber {
	public void update();
}
